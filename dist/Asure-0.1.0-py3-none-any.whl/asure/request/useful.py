
def recoverage(key):
    return key.replace('-', '_')