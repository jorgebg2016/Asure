def encode_data(data):
    return data.encode('utf8')

def decode_data(data):
    return data.decode('utf8')